package be.oreel.masi.shoppinglist.activity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.List;

import be.oreel.masi.shoppinglist.adapter.ArticleAdapter;
import be.oreel.masi.shoppinglist.model.Article;
import be.oreel.masi.shoppinglist.db.ArticleDataSource;
import be.oreel.masi.shoppinglist.R;

/**
 * Activity displaying and handling the articles of a shop
 */
public class ArticleActivity extends RecyclerActivity {

    // =================
    // === VARIABLES ===
    // =================

    private String shopName;
    private ArticleDataSource datasource;
    private RecyclerView.Adapter adapter;
    private List<Article> articles;

    // ================
    // === ONCREATE ===
    // ================

    /**
     * Create the ArticleActivity
     * @param savedInstanceState The saved instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle b = getIntent().getExtras();
        // Get the selected shop name from the MainActivity
        shopName = b != null ? b.getString(getString(R.string.bundle_shopname_id)) : null;
        if(getSupportActionBar() != null){
            // Set the shop name as the title of this activity
            getSupportActionBar().setTitle(
                    shopName != null ?
                            shopName :
                            getString(R.string.article_activity_title));
        }

        datasource = new ArticleDataSource(this);
        // Open the database
        datasource.open();
        // Get all the articles from the chosen shop
        articles = datasource.getAllArticles(shopName);

        // Create the adapter for the recyclerView
        adapter = new ArticleAdapter(getCoordinatorLayout(), articles, datasource);
        getRecyclerView().setAdapter(adapter);
    }

    // =================================================
    // === ABSTRACT PARENT FUNCTIONS IMPLEMENTATIONS ===
    // =================================================

    /**
     * Sets the toolbar
     */
    @Override
    protected void setupToolbar() {
        setSupportActionBar(getToolbar());
        if (getSupportActionBar() != null) {
            //  Set the back arrow on top left of the toolbar
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    /**
     * Sets the FAB
     */
    @Override
    protected void setupFab() {
        FloatingActionButton fab = getFab();
        if (fab != null) {
            fab.bringToFront();
            fab.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    addArticle();
                }
            });
            fab.setImageDrawable(ContextCompat.getDrawable(getBaseContext(),
                    R.drawable.ic_add_white_24px));
        }
    }

    // ============================
    // === ACTION BAR FUNCTIONS ===
    // ============================

    /**
     * Sets the actions to perform for each element in the action bar
     * @param item The menu item being pressed
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id){
            case android.R.id.home:
                // Back button brings you back to the MainActivity
                onBackPressed();
                break;
            case R.id.action_remove_all:
                // Removes all articles of that shop
                removeAllArticles();
                break;
            case R.id.action_exit_app:
                // Leaves the app
                leaveApp();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Creates the menu in the action bar
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.article_menu, menu);
        return true;
    }

    // ====================
    // === DB FUNCTIONS ===
    // ====================

    /**
     * Creates a dialog to add an article to the list
     */
    private void addArticle(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // Get the elements from the dialog content
        LinearLayout contentParent = (LinearLayout) getLayoutInflater().
                inflate(R.layout.dialog_create_article, null);
        final EditText inputName = (EditText) contentParent.getChildAt(0);
        final EditText inputAmount = (EditText) contentParent.getChildAt(1);

        builder.setView(contentParent).
                setTitle(R.string.dialog_title_add_article).
                setPositiveButton(R.string.dialog_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Add the article
                        Article newArticle = datasource.createArticle(shopName,
                                inputName.getText().toString(),
                                inputAmount.getText().toString());
                        articles.add(newArticle);
                        adapter.notifyItemInserted(articles.size() - 1);
                    }
                }).
                setNegativeButton(R.string.dialog_cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {}
                }).
                create().
                show();
    }

    /**
     * Removes all the articles of the shop
     */
    private void removeAllArticles(){
        int size = articles.size();
        articles.clear();
        adapter.notifyItemRangeRemoved(0, size);
        datasource.deleteAllArticles(shopName);
        // Show snackbar
        Snackbar snackbar = Snackbar.make(getCoordinatorLayout(), String.format(getString(R.string.snackbar_remove_all), shopName), Snackbar.LENGTH_LONG);
        snackbar.show();
    }

    /**
     * Opens the database on resume of the activity
     */
    @Override
    protected void onResume() {
        datasource.open();
        super.onResume();
    }

    /**
     * Closes the database on pause of the activity
     */
    @Override
    protected void onPause() {
        datasource.close();
        super.onPause();
    }
}
