package be.oreel.masi.shoppinglist.adapter;

import android.content.DialogInterface;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

import be.oreel.masi.shoppinglist.R;
import be.oreel.masi.shoppinglist.db.ArticleDataSource;
import be.oreel.masi.shoppinglist.model.Article;

/**
 * The adapter for the recyclerView of the ArticleActivity
 */
public class ArticleAdapter extends RecyclerView.Adapter<ArticleAdapter.ViewHolder> {

    // =================
    // === VARIABLES ===
    // =================

    private CoordinatorLayout coordinatorLayout;
    private List<Article> articleDataset;
    private ArticleDataSource datasource;

    // ===================
    // === CONSTRUCTOR ===
    // ===================

    /**
     * The conctructor
     * @param articleDataset A list of articles
     * @param datasource The datasource of the articles
     */
    public ArticleAdapter(CoordinatorLayout coordinatorLayout, List<Article> articleDataset,
                          ArticleDataSource datasource) {
        this.coordinatorLayout = coordinatorLayout;
        this.articleDataset = articleDataset;
        this.datasource = datasource;
    }

    // ==================
    // === VIEWHOLDER ===
    // ==================

    /**
     * The article ViewHolder
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {

        public LinearLayout contentParent;
        public TextView tvName;
        public TextView tvAmount;
        public ViewHolder(LinearLayout v) {
            super(v);
            contentParent = v;
            tvName = (TextView) v.findViewById(R.id.article_name);
            tvAmount = (TextView) v.findViewById(R.id.article_amount);
        }
    }

    // =========================
    // === ADAPTER FUNCTIONS ===
    // =========================

    /**
     * Creates the new views (invoked by the layout manager)
     * @param parent
     * @param viewType
     * @return The new viewHolder
     */
    @Override
    public ArticleAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LinearLayout v = (LinearLayout) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.article_template, parent, false);
        return new ViewHolder(v);
    }

    /**
     * Replaces the contents of a view (invoked by the layout manager)
     * @param holder
     * @param position
     */
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        // getAdapterPosition is used instead of position, since it gives back the right position!
        // Get the targeted article
        final Article article = articleDataset.get(holder.getAdapterPosition());
        // Set the fields of the article in the viewHolder
        holder.tvName.setText(article.getName());
        holder.tvAmount.setText(article.getAmount());
        // Set the long click listener with the 3 options: change name, change amount, remove
        holder.contentParent.setOnCreateContextMenuListener(new View.OnCreateContextMenuListener() {
            @Override
            public void onCreateContextMenu(ContextMenu menu, final View v,
                                            ContextMenu.ContextMenuInfo contextMenuInfo) {
                MenuItem updateNameItem = menu.add(R.string.dialog_option_update_article_name);
                updateNameItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        // Create the dialog to change the name
                        AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());

                        LinearLayout contentParent = (LinearLayout) LayoutInflater.from(v.getContext()).
                                inflate(R.layout.dialog_update_article, null);
                        final EditText input = (EditText) contentParent.getChildAt(0);
                        input.setHint(R.string.placeholder_article_name);
                        input.setText(article.getName());

                        builder.setView(contentParent).
                                setTitle(R.string.dialog_title_change_article_name).
                                setPositiveButton(R.string.dialog_ok, new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // Apply the change
                                        article.setName(input.getText().toString());
                                        notifyItemChanged(holder.getAdapterPosition());
                                        datasource.updateArticle(article);
                                    }
                                }).
                                setNegativeButton(R.string.dialog_cancel, new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {}
                                }).
                                create().
                                show();
                        return false;
                    }
                });
                MenuItem updateAmountItem = menu.add(R.string.dialog_option_update_article_amount);
                updateAmountItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        // Create the dialog to change the amount
                        AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());

                        LinearLayout contentParent = (LinearLayout) LayoutInflater.from(v.getContext()).
                                inflate(R.layout.dialog_update_article, null);
                        final EditText input = (EditText) contentParent.getChildAt(0);
                        input.setHint(R.string.placeholder_article_amount);
                        input.setText(article.getAmount());

                        builder.setView(contentParent).
                                setTitle(R.string.dialog_title_change_article_amount).
                                setPositiveButton(R.string.dialog_ok, new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // Apply the change
                                        article.setAmount(input.getText().toString());
                                        notifyItemChanged(holder.getAdapterPosition());
                                        datasource.updateArticle(article);
                                    }
                                }).
                                setNegativeButton(R.string.dialog_cancel, new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {}
                                }).
                                create().
                                show();
                        return false;
                    }
                });
                MenuItem removeItem = menu.add(R.string.dialog_option_remove_article);
                removeItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        // Removes the article
                        articleDataset.remove(holder.getAdapterPosition());
                        notifyItemRemoved(holder.getAdapterPosition());
                        datasource.deleteArticle(article);
                        // Show snackbar
                        Snackbar snackbar = Snackbar.make(coordinatorLayout,
                                String.format(v.getContext().getResources().
                                        getString(R.string.snackbar_remove_article),
                                        article.toString()), Snackbar.LENGTH_LONG);
                        snackbar.show();
                        return false;
                    }
                });
            }
        });
    }

    /**
     * Returns the size of the dataset (invoked by the layout manager)
     * @return The size of the dataset
     */
    @Override
    public int getItemCount() {
        return articleDataset.size();
    }
}