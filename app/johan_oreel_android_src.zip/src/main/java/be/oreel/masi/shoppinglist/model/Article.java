package be.oreel.masi.shoppinglist.model;

/**
 * The article model
 */
public class Article {

    // =================
    // === VARIABLES ===
    // =================

    private long id;
    private String shop;
    private String name;
    private String amount;

    @Override
    public String toString(){
        return getName();
    }

    // =========================
    // === GETTERS & SETTERS ===
    // =========================

    /**
     * Returns the id of the article
     * @return The id of the article
     */
    public long getId() {
        return id;
    }

    /**
     * Sets the id of an article
     * @param id The id to be set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Returns the name of the article's shop
     * @return The name of the article's shop
     */
    public String getShop() {
        return shop;
    }

    /**
     * Sets the name of the article's shop
     * @param shop The shop name to be set
     */
    public void setShop(String shop) {
        this.shop = shop;
    }

    /**
     * Returns the name of the article
     * @return The name of the article
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the article
     * @param name The name to be set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the amount of the article
     * @return The amount of the article
     */
    public String getAmount() {
        return amount;
    }

    /**
     * Sets the amount of the article
     * @param amount The amount to be set
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }
}
